package javasession;

import java.util.ArrayList;

public class ArrayListTest {
	
	public static void main(String[] args) {
		//* to print static array use below format
		//system.out.println(Array.toString(static array name));
		/*ArrayList<String> names = new ArrayList<String>();
		
		System.out.println(names.size());
		
		names.add("Tom");//0
		names.add("Nik");//1
		names.add("Danny");//2
		names.add("Krish");//3  
		System.out.println(names) 
		to sort  use collections.sort(names);System.out.println(names)
		collections.swap(names,1,2);System.out.println(names)*/
		
		/* method in java  is Clear and  "contains" so 
		 * emp.clear();
		 * System.out.println(emp) its clear record
		 * if (emp.contains("Tom")){
		 * System.out.println("Tom is present")}
		 * System.out.println(emp) its clear record
		 */

		ArrayList<Integer> marksList = new ArrayList<Integer>();
		
		System.out.println(marksList.size());
		
		marksList.add(100);//0
		marksList.add(200);//1
		marksList.add(11);//2
		marksList.add(20);//3
		
		System.out.println(marksList.get(0));//100

		System.out.println(marksList.get(2));
		
		//marksList.remove(2);
		
		System.out.println(marksList.get(2));
		
		marksList.add(400);
		
		System.out.println(marksList.get(3));
		
		marksList.add(0, 150);
		System.out.println(marksList.get(0));//150

//		marksList.add(7, 1000);
//		System.out.println(marksList.get(7));
		
		for(int i=0; i<marksList.size(); i++) {
			System.out.println(i+ ":" + marksList.get(i));
		}
		
		
	}

}