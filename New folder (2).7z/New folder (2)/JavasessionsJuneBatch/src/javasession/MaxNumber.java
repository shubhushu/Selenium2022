package javasession;

public class MaxNumber {

	public static void main(String[] args) {
		//
		
		int b = 06517;
		System.out.println(b);
		//0651 = (0 × 8³) + (6 × 8²) + (5 × 8¹) + (1 × 8⁰) = 425
		System.out.println(0/0/0);
		int le=2;
		int re =le+++le+++le--;
		System.out.println(re);
		System.out.println(le);
			}

}
