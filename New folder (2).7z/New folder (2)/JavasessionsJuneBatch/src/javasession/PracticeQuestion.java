package javasession;

public class PracticeQuestion {

	public static void main(String[] args) {
		
		int i = 1;
		while (i <= 10) {
			System.out.println("Hello world");//
			i++;
			// ++i;
			// i=i+1;
		}

}

}