package oop_Inheritance;

public class Vehicle {

	public void engine() {
		System.out.println("vehicle -- engine");
	}

}