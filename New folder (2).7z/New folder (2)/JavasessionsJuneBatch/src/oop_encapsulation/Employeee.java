//reffered refreshjava
package oop_encapsulation;
class Employeee {  
    String name, address;
    int age;
    //create constructor 1
    public Employeee(String name, int age) {
      this(name, age, "NA"); // calling constructor
    }
    //create constructor 2
    public Employeee(String name, int age, String address) {
      // this.name refers name instance variable while using only 
      //name refers name parameter, this way we resolve name conflict.
      this.name = name; 
      this.age = age;
      this.address = address;
    } 
    //create method 1
    public void printDetail() {
      System.out.println("Name = "+this.name+", age = "+this.age);
      System.out.println("Address = "+this.address);
      this.checkVoterEligibility(this.age); // calling method using this keyword
    }
    ////create method 2
    public void checkVoterEligibility(int age) {
      if(age > 18) { System.out.println("You are eligible for vote"); }
      else { System.out.println("You are not eligible for vote"); }
    }  
    //main method
    public static void main(String [] args) {
      Employeee employee = new Employeee("Rahul", 20);  //created object1
      employee.printDetail(); //call method with object 1
      Employeee employee2 = new Employeee("Pradeep", 22, "xyz");  //created object 2
      employee2.printDetail();    //call method with object 2       
    }
 }