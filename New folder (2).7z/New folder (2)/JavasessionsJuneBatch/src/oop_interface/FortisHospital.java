package oop_interface;

public class FortisHospital implements US_Medical,UK_Medical,INDIAN_Medical{

	@Override
	public void pediaservices() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void orthoservices() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void physioservices() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ENTServices() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cardioServices() {
		// TODO Auto-generated method stub
		
	}


	}


