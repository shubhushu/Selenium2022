package oop_interface;

public interface INDIAN_Medical {
	public void oncologyServices();
	public void hearts
	

}
