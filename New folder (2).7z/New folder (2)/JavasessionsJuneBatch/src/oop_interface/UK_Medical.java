package oop_interface;

public interface UK_Medical {
	
	public void ENTServices();
	public void cardioServices();
	

}
