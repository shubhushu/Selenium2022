package oop_interface;

public interface US_Medical {
	
	public void pediaservices();
	public void orthoservices();
	public void physioservices();
	

}
