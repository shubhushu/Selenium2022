package com.qa.opencart.errors;

public class AppError {

}
