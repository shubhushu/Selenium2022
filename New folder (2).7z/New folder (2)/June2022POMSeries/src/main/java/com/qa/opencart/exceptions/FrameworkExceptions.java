package com.qa.opencart.exceptions;

public class FrameworkExceptions {

}
