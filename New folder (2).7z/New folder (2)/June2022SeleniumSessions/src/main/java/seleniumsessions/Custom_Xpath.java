package seleniumsessions;

public class Custom_Xpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
