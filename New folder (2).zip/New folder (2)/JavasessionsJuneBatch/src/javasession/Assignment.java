package javasession;

public class Assignment {

	public static void main(String[] args) {
		
	
//		assignment 1. WAP to print following output:
//		 
//		I am Batman﻿
//		I am Batman﻿
//		I am Batman﻿
//		I am Batman
//		I am Batman
		//for (int i = 0; i < 5; i++)
		
		//System.out.println("I am Batman");
		
//	*	assignment 2. WAP to print following output:

		//for (int i = 0; i < 10; i++)
			
	   // System.out.println ("I am Batman" +i);
		
		//3. WAP to print 10 to 1 using for, while and do-while loop
		
//		int l=10;
//		while(l>=1)
//		{
//			System.out.println(l);
//			l--;
//		}
//		
		//assignment 4. WAP to print 10 time hellow world:
//		int i = 1;
//		while (i <= 10) {
//			System.out.println("Hello world");//
//			i++;
//	    }
		
		// 5. Write a program in Java to print 1 to 10 using while loop
		
//		int k = 1;
//		while (k <= 10) {
//			System.out.println(k);//
//			k++;
				
		//7. print all odd and even numbers between 1 to 100
		
		System.out.println("even number between 1 to 100");
		for(int number=1; number<=100; number++)
		{
		   if (number % 2==0 )
			{
			   { 
					System.out.println( number+ "");
			   }
			}
		System.out.println("Odd number between 1 to 100");
			for(int number1=1; number1<=100; number1++)
			{
				if (number1 % 2!=0 )
				{
					{ 
						System.out.println( number1+ "");
					}
				}
			   }
		     }
		//8. What will be the output of this program://infinite loop
			int i = 1;
			while(i<=1)
			{
			System.out.println("Hi Java");
			i++;
			}
			
				
			
			//3. Write a program that will  print out the last character and first character of a word.
			
			char word = 1;
			while(i<=1)
			{
			System.out.println("Hi Java");
			i++;
			}
	
	}
	
	
}
			
					
	

