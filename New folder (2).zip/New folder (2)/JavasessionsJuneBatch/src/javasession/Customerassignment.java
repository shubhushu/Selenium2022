package javasession;

public class Customerassignment {
	String name;
	int age;
	String customertype;
	

	public static void main(String[] args) {
		
		Customerassignment c1 = new Customerassignment();
		c1.name= "Shubh";
		c1.age = 30;
		c1.customertype= "Privilaged";
		
		Customerassignment c2 = new Customerassignment();
		c2.name= "Sarika";
		c2.age = 39;
		c2.customertype= "Privilaged";
		
		Customerassignment c3 = new Customerassignment();
		c3.name= "Pankaj";
		c3.age = 34;
		c3.customertype= "Privilaged";
		
		Customerassignment c4 = new Customerassignment();
		c4.name= "Bhushan";
		c4.age = 40;
		c4.customertype= "Privilaged";
		
		System.out.println(c1.name +" " + c1.age + " " + c1.customertype);
		System.out.println(c2.name +" " + c2.age + " " + c2.customertype);
		System.out.println(c3.name +" " + c3.age + " " + c3.customertype);
		System.out.println(c4.name +" " + c4.age + " " + c4.customertype);
		
		c1=c2;
		System.out.println("---------");
		System.out.println(c1.name +" " + c1.age + " " + c1.customertype);
		System.out.println(c2.name +" " + c2.age + " " + c2.customertype);
		System.out.println(c3.name +" " + c3.age + " " + c3.customertype);
		System.out.println(c4.name +" " + c4.age + " " + c4.customertype);
		
		c2=c3;
		System.out.println("---------");
		System.out.println(c1.name +" " + c1.age + " " + c1.customertype);
		System.out.println(c2.name +" " + c2.age + " " + c2.customertype);
		System.out.println(c3.name +" " + c3.age + " " + c3.customertype);
		System.out.println(c4.name +" " + c4.age + " " + c4.customertype);
		
		c3=c4;
		
		System.out.println("---------");
		System.out.println(c1.name +" " + c1.age + " " + c1.customertype);
		System.out.println(c2.name +" " + c2.age + " " + c2.customertype);
		System.out.println(c3.name +" " + c3.age + " " + c3.customertype);
		System.out.println(c4.name +" " + c4.age + " " + c4.customertype);
		
		c4=c1;
		System.out.println("---------");
		System.out.println(c1.name +" " + c1.age + " " + c1.customertype);
		System.out.println(c2.name +" " + c2.age + " " + c2.customertype);
		System.out.println(c3.name +" " + c3.age + " " + c3.customertype);
		System.out.println(c4.name +" " + c4.age + " " + c4.customertype);
		
				

	}

}
