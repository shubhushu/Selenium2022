package javasession;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		byte b =2;
		short s=b;
		long l= b;
		int i=b;
		
		System.out.println(b);
		System.out.println(s);
		
		int p=100;
		short s1= (short)p;
		byte b1= (byte)p;
		
		System.out.println(s1);
		System.out.println(b1);
	
					
		byte m= 110;
		byte n= 114;
		int t1 =m+n;
		byte t= (byte)(m+n);
		
		System.out.println(t);
		System.out.println(t1);
		
		char c=97;
		System.out.println(c+'b');
		
	
	}

}
