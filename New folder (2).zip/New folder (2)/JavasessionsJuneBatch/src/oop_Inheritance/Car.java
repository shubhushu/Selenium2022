package oop_Inheritance;

public class Car {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
