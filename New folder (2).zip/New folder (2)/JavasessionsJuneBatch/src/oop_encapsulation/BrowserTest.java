package oop_encapsulation;

public class BrowserTest {

	public static void main(String[] args) {

				
		Browser br = new Browser();
		br.launchBrowser();
		
				
	}

}