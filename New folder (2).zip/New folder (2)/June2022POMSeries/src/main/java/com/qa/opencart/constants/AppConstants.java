package com.qa.opencart.constants;

public class AppConstants {

}
