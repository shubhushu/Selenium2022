package com.qa.opencart.factory;

import org.openqa.selenium.WebDriver;

public class DriverFactory {
	
	public WebDriver driver;
	 public void initDriver(String browserName) {
		 System.out.println("browser name is: " +browserName .equals(+browserName));
		 
		 if(browserName.equals("chrome"))
	}
	 

}
