package com.qa.opencart.test;

public class LoginPageTest {

}
