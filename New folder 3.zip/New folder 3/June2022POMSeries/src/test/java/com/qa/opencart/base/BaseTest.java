package com.qa.opencart.base;

public class BaseTest {

}
